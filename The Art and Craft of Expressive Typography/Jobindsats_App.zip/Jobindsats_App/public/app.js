const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const state = {
  subjects: [],
  tables: [],
  filteredTables: [],
  selectedSubject: null,
  selectedTable: null,
  tableMeta: null, // /tables/{id}
  tableListMeta: null, // entry from /tables?subjectid=..
  aiReady: false,
  chart: null,
};

function html(strings, ...vals) {
  return strings.reduce((acc, s, i) => acc + s + (vals[i] ?? ""), "");
}

function setStatus(msg, ok = true) {
  const el = document.getElementById("status");
  el.textContent = msg;
  el.classList.toggle("muted", ok);
}

function setStep(n) {
  const steps = $$("#stepper .step");
  steps.forEach((s) => s.classList.remove("active"));
  steps.forEach((s) => {
    const stepNo = Number(s.getAttribute("data-step"));
    if (stepNo <= n) s.classList.add("active");
  });
}

async function api(path) {
  const r = await fetch(path);
  if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
  return r;
}

async function init() {
  try {
    const h = await api("/api/health").then((r) => r.json());
    setStatus(h.tokenConfigured ? "API klar" : "Token mangler — sæt JOBINDSATS_TOKEN");
    state.aiReady = !!h.aiReady;
    const aiReady = document.getElementById("aiReady");
    aiReady.textContent = state.aiReady ? "Gemini klar" : "Gemini ikke konfigureret";
  } catch (e) {
    setStatus("Server ikke kørende?", false);
  }

  await loadSubjects();
  bindSearch();
  bindAI();

  // Intro helpers
  $$("[data-fill-ai]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const ta = document.getElementById("aiQuestion");
      ta.value = btn.getAttribute("data-fill-ai") || "";
      document.getElementById("aiBox").scrollIntoView({ behavior: "smooth", block: "start" });
      ta.focus();
    });
  });

  // Quick period chips
  const chipsWrap = document.querySelector(".quick-periods");
  if (chipsWrap) {
    chipsWrap.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-period]");
      if (!btn) return;
      const val = btn.getAttribute("data-period");
      if (val === "custom") {
        document.getElementById("periodDetails").open = true;
        return;
      }
      // Parse like l(M:12)
      const m = /^l\(([A-Z]+):(\d+)\)$/.exec(val || "");
      if (m) {
        document.querySelector('input[name="periodMode"][value="latest"]').checked = true;
        document.getElementById("periodCatLatest").value = m[1];
        document.getElementById("periodLatestN").value = m[2];
        updateUrlPreview();
      }
    });
  }

  // Copy URL
  const copyBtn = document.getElementById("copyUrl");
  if (copyBtn) {
    copyBtn.addEventListener("click", async () => {
      const code = document.getElementById("urlPreview").textContent.trim();
      if (!code) return;
      try {
        await navigator.clipboard.writeText(code);
        copyBtn.textContent = "Kopieret";
        setTimeout(() => (copyBtn.textContent = "Kopiér"), 1200);
      } catch {}
    });
  }

  // Initial step
  setStep(1);
}

async function loadSubjects() {
  const subjects = await api("/api/subjects").then((r) => r.json());
  state.subjects = subjects;
  renderSubjects(subjects);
}

function renderSubjects(subjects) {
  const ul = document.getElementById("subjects");
  ul.innerHTML = "";
  subjects.forEach((s) => {
    const li = document.createElement("li");
    li.innerHTML = html`<strong>${s.SubjectName}</strong> <small>(${s.SubjectID})</small>`;
    li.addEventListener("click", () => selectSubject(s));
    ul.appendChild(li);
  });
}

async function selectSubject(subject) {
  state.selectedSubject = subject;
  document.getElementById("tableDetails").hidden = true;
  document.getElementById("results").hidden = true;
  document.getElementById("intro").hidden = true;
  const subjBadge = document.getElementById("currentSubject");
  subjBadge.hidden = false;
  subjBadge.textContent = subject.SubjectName;
  setStep(2);
  const url = `/api/tables?subjectid=${encodeURIComponent(subject.SubjectID)}`;
  const tablesWrap = document.getElementById("tables");
  const emptyMsg = document.getElementById("tablesEmpty");
  tablesWrap.setAttribute("aria-busy", "true");
  emptyMsg.hidden = true;
  const tables = await api(url).then((r) => r.json()).finally(() => tablesWrap.removeAttribute("aria-busy"));
  state.tables = tables;
  state.filteredTables = tables;
  renderTables();
}

function bindSearch() {
  const subjSearch = document.getElementById("subjectSearch");
  subjSearch.addEventListener("input", () => {
    const q = subjSearch.value.toLowerCase();
    const filtered = state.subjects.filter((s) =>
      s.SubjectName.toLowerCase().includes(q) || String(s.SubjectID).includes(q)
    );
    renderSubjects(filtered);
  });

  const tableSearch = document.getElementById("tableSearch");
  tableSearch.addEventListener("input", () => {
    const q = tableSearch.value.toLowerCase();
    state.filteredTables = state.tables.filter((t) =>
      t.TableName.toLowerCase().includes(q) || String(t.TableID).toLowerCase().includes(q)
    );
    renderTables();
  });
}

function renderTables() {
  const wrap = document.getElementById("tables");
  wrap.innerHTML = "";
  const list = state.filteredTables || [];
  if (!list.length) {
    const msg = document.getElementById("tablesEmpty");
    if (state.selectedSubject) {
      msg.textContent = "Ingen tabeller matcher din søgning.";
    } else {
      msg.textContent = "Vælg først et emne for at se relevante tabeller.";
    }
    msg.hidden = false;
    return;
  } else {
    document.getElementById("tablesEmpty").hidden = true;
  }

  list.forEach((t) => {
    const card = document.createElement("div");
    card.className = "card";
    const dims = (t.Dimensions || []).map((d) => d.DimensionName).join(", ");
    const periods = (t.PeriodCategory || []).join(", ");
    const areas = (t.AreaHierarchy || []).join(", ");
    card.innerHTML = html`
      <h5>${t.TableName}</h5>
      <p class="muted">ID: <strong>${t.TableID}</strong></p>
      <p class="muted">Perioder: ${periods || "–"}</p>
      <p class="muted">Områder: ${areas || "–"}</p>
      <p class="muted">Dimensioner: ${dims || "–"}</p>
      <p class="muted">Målevariable: ${(t.Measurements || []).map((m) => m.ID).join(", ") || "–"}</p>
    `;
    card.addEventListener("click", () => selectTable(t));
    wrap.appendChild(card);
  });
}

async function selectTable(tableListMeta) {
  state.selectedTable = tableListMeta.TableID;
  state.tableListMeta = tableListMeta;
  const td = document.getElementById("tableDetails");
  td.hidden = false;
  document.getElementById("results").hidden = true;
  setStep(3);

  // Load detailed meta
  const detail = await api(`/api/tables/${encodeURIComponent(state.selectedTable)}`).then((r) => r.json());
  state.tableMeta = detail;
  renderTableDetails();
}

function renderTableDetails() {
  const meta = state.tableMeta;
  const listMeta = state.tableListMeta || {};
  document.getElementById("tableTitle").textContent = `${meta.TableName} (${meta.TableID})`;

  // Measurements
  const measEl = document.getElementById("measurement");
  measEl.innerHTML = "";
  const measurements = (listMeta.Measurements || []).map((m) => ({ id: m.ID, name: m.Name }));
  const noneOpt = document.createElement("option");
  noneOpt.value = "";
  noneOpt.textContent = "(Alle / ingen specifik)";
  measEl.appendChild(noneOpt);
  measurements.forEach((m) => {
    const opt = document.createElement("option");
    opt.value = m.id;
    opt.textContent = `${m.name} (${m.id})`;
    measEl.appendChild(opt);
  });

  // Areas
  const areaEl = document.getElementById("area");
  areaEl.innerHTML = "";
  (meta.Area || ["Hele landet"]).forEach((a) => {
    const opt = document.createElement("option");
    opt.value = a;
    opt.textContent = a;
    if (a.toLowerCase() === "hele landet") opt.selected = true;
    areaEl.appendChild(opt);
  });

  // Dimensions
  const dimsWrap = document.getElementById("dimensions");
  dimsWrap.innerHTML = "";
  (meta.Dimensions || []).forEach((d) => {
    const field = document.createElement("div");
    field.innerHTML = html`
      <label for="dim_${d.DimensionID}">${d.DimensionName} <small class="muted">(${d.DimensionID})</small></label>
      <select id="dim_${d.DimensionID}" name="${d.DimensionID}" multiple size="5"></select>
      <small>Tom = default (${d.DefaultValue}). Vælg flere med Cmd/Ctrl.</small>
    `;
    const sel = field.querySelector("select");
    (d.Values || []).forEach((v) => {
      const opt = document.createElement("option");
      opt.value = v;
      opt.textContent = v;
      sel.appendChild(opt);
    });
    dimsWrap.appendChild(field);
  });

  // Wire actions
  document.getElementById("run").onclick = runQuery;
  updateUrlPreview();
}

function readSelections(selectEl) {
  return Array.from(selectEl.selectedOptions).map((o) => o.value);
}

function buildPeriodParam() {
  const mode = document.querySelector('input[name="periodMode"]:checked').value;
  if (mode === "latest") {
    const cat = document.getElementById("periodCatLatest").value;
    const n = Math.max(1, Math.min(499, Number(document.getElementById("periodLatestN").value) || 1));
    return `l(${cat}:${n})`;
  } else {
    const cat = document.getElementById("periodCatRange").value;
    const start = document.getElementById("periodStart").value.trim();
    const end = document.getElementById("periodEnd").value.trim();
    if (!start || !end) return null;
    return `r(${cat}:${start}-${end})`;
  }
}

function buildQuery() {
  const meta = state.tableMeta;
  const qs = new URLSearchParams();

  // area (required)
  const areas = readSelections(document.getElementById("area"));
  if (!areas.length) return { error: "Vælg mindst ét område (area)" };
  qs.set("area", areas.join(","));

  // period (required)
  const period = buildPeriodParam();
  if (!period) return { error: "Udfyld periode (latest eller range)" };
  qs.set("period", period);

  // measurement (optional)
  const m = document.getElementById("measurement").value;
  if (m) qs.set("measurement", m);

  // dimensions (optional; omit to use DefaultValue)
  (meta.Dimensions || []).forEach((d) => {
    const sel = document.getElementById(`dim_${d.DimensionID}`);
    if (sel) {
      const vals = readSelections(sel);
      if (vals.length) qs.set(d.DimensionID, vals.join(","));
    }
  });

  return { qs };
}

function updateUrlPreview() {
  const out = document.getElementById("urlPreview");
  const tab = state.selectedTable;
  if (!tab) return (out.textContent = "");
  const built = buildQuery();
  if (built.error) { out.textContent = built.error; return; }
  out.textContent = `/v2/data/${tab}/json?${built.qs.toString()}`;
  const csv = document.getElementById("csv");
  csv.href = `/api/data/${encodeURIComponent(tab)}?format=csv&${built.qs.toString()}`;
  csv.download = `${tab}.csv`;
}

async function runQuery() {
  const tab = state.selectedTable;
  const built = buildQuery();
  if (built.error) { alert(built.error); return; }
  const url = `/api/data/${encodeURIComponent(tab)}?${built.qs.toString()}`;
  const btn = document.getElementById("run");
  btn?.setAttribute("aria-busy", "true");
  const data = await api(url).then((r) => r.json()).finally(() => btn?.removeAttribute("aria-busy"));
  renderResults(data);
}

function renderResults(payload) {
  const res = document.getElementById("results");
  res.hidden = false;
  const raw = document.getElementById("raw");
  raw.textContent = JSON.stringify(payload, null, 2);

  const table = document.getElementById("dataTable");
  table.innerHTML = "";

  // Expect structure: { Variables: [{Name,Label}...], Data: [[...], ...] }
  const root = Array.isArray(payload) ? payload[0] : payload;
  const vars = root?.Variables;
  const rows = root?.Data;
  if (!Array.isArray(vars) || !Array.isArray(rows)) {
    table.innerHTML = "<tbody><tr><td>Ukendt svarformat</td></tr></tbody>";
    return;
  }

  const thead = document.createElement("thead");
  const htr = document.createElement("tr");
  vars.forEach((v) => {
    const th = document.createElement("th");
    th.textContent = v.Label || v.Name;
    htr.appendChild(th);
  });
  thead.appendChild(htr);

  const tbody = document.createElement("tbody");
  rows.forEach((r) => {
    const tr = document.createElement("tr");
    r.forEach((cell) => {
      const td = document.createElement("td");
      const num = Number(cell);
      if (!Number.isNaN(num) && /^(?:-?\d{1,3}(?:[\d]*)?(?:\.\d+)?)$/.test(String(cell))) {
        td.textContent = num.toLocaleString("da-DK");
        td.style.textAlign = "right";
      } else {
        td.textContent = cell;
      }
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });

  table.appendChild(thead);
  table.appendChild(tbody);

  // Update step and optional chart
  setStep(4);
  prepareViewSwitch(vars, rows);
}

// Update preview whenever controls change
document.addEventListener("change", (e) => {
  if (["periodCatLatest","periodLatestN","periodCatRange","periodStart","periodEnd","measurement","area"].includes(e.target.id)) {
    updateUrlPreview();
  }
  if (e.target.name === "periodMode") updateUrlPreview();
  if (e.target.id?.startsWith("dim_")) updateUrlPreview();
});

init();

// ---------- AI ----------
function bindAI() {
  const btn = document.getElementById("aiAsk");
  const ta = document.getElementById("aiQuestion");
  btn.addEventListener("click", async () => {
    const q = ta.value.trim();
    if (!q) return;
    btn.setAttribute("aria-busy", "true");
    const resBox = document.getElementById("aiResult");
    const ans = document.getElementById("aiAnswer");
    const planEl = document.getElementById("aiPlan");
    const queriesEl = document.getElementById("aiQueries");
    resBox.hidden = true; ans.textContent = ""; planEl.textContent = ""; queriesEl.textContent = "";
    try {
      // Use deterministic fast QA route to avoid wrong table picks
      const r = await fetch("/api/qa/ask", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question: q }) });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || r.statusText);
      ans.textContent = data.answer?.finalAnswer || "(intet svar)";
      planEl.textContent = JSON.stringify(data.plan, null, 2);
      // Render queries list
      queriesEl.innerHTML = "";
  (data.executed || []).forEach((ex) => {
    const div = document.createElement("div");
    const openLink = document.createElement("a");
    openLink.href = `#`;
    openLink.textContent = `Åbn i data-UI (${ex.table?.id})`;
    openLink.addEventListener("click", async (ev) => {
      ev.preventDefault();
      await openExecutedInExplorer(ex);
    });
    const csvA = document.createElement("a");
    const params = new URLSearchParams(ex.params || {});
    csvA.href = `/api/data/${encodeURIComponent(ex.table?.id)}?format=csv&${params.toString()}`;
    csvA.textContent = "Download CSV";
    csvA.style.marginLeft = ".5rem";
    const makeTbl = document.createElement("button");
    makeTbl.textContent = "Create table";
    makeTbl.className = "secondary";
    makeTbl.style.marginLeft = ".5rem";
    const vizHolder = document.createElement("div");
    vizHolder.className = "viz";
    makeTbl.addEventListener("click", async () => {
      makeTbl.setAttribute("aria-busy", "true");
      try {
        await renderAiTableForExecuted(ex, vizHolder, data?.answer?.finalAnswer || ans.textContent || "");
      } finally {
        makeTbl.removeAttribute("aria-busy");
      }
    });
    const p = document.createElement("p");
    p.className = "muted";
    p.textContent = `${ex.table?.name || ex.table?.id} — ${ex.reason || ""}`;
    const code = document.createElement("code");
    code.textContent = ex.dataUrl || "";
    div.appendChild(p);
    div.appendChild(code);
    div.appendChild(document.createElement("br"));
    div.appendChild(openLink);
    div.appendChild(csvA);
    div.appendChild(makeTbl);
    div.appendChild(vizHolder);
    queriesEl.appendChild(div);
  });
      resBox.hidden = false;
    } catch (e) {
      ans.textContent = `Fejl: ${e.message}`;
      resBox.hidden = false;
    } finally {
      btn.removeAttribute("aria-busy");
    }
  });
}

// Open an executed AI query in the manual explorer by loading its subject and selecting the table
async function openExecutedInExplorer(ex) {
  const tabId = String(ex.table?.id || "");
  const detail = ex.detail || {};
  // Resolve subject from detail if present
  const subject = state.subjects.find((s) => String(s.SubjectID) === String(detail.SubjectID))
    || state.subjects.find((s) => (s.SubjectName || "").toLowerCase() === String(detail.SubjectName || "").toLowerCase());
  if (subject) {
    await selectSubject(subject);
    const t = state.tables.find((t) => String(t.TableID).toLowerCase() === tabId.toLowerCase());
    if (t) {
      await selectTable(t);
      window.scrollTo({ top: document.getElementById("tableDetails").offsetTop - 20, behavior: "smooth" });
      return;
    }
  }
  // Fallback: fetch detail directly and use minimal list meta
  try {
    const meta = await api(`/api/tables/${encodeURIComponent(tabId)}`).then((r) => r.json());
    const fallback = { TableID: meta.TableID, TableName: meta.TableName, Measurements: [] };
    state.tables = [fallback];
    state.filteredTables = [fallback];
    renderTables();
    await selectTable(fallback);
    window.scrollTo({ top: document.getElementById("tableDetails").offsetTop - 20, behavior: "smooth" });
  } catch {}
}

// Fetch dataset and render a neat table plus an AI-generated comment
async function renderAiTableForExecuted(ex, holder, previousAnswerText) {
  holder.innerHTML = "";
  const params = new URLSearchParams(ex.params || {});
  const url = `/api/data/${encodeURIComponent(ex.table?.id)}?${params.toString()}`;
  const payload = await api(url).then((r) => r.json());
  const root = Array.isArray(payload) ? payload[0] : payload;
  const vars = root?.Variables || [];
  const rows = root?.Data || [];

  const title = document.createElement("h5");
  title.textContent = `${ex.table?.name || ex.table?.id}`;
  holder.appendChild(title);

  const tblWrap = document.createElement("div");
  tblWrap.className = "tableWrap";
  const table = document.createElement("table");
  table.className = "striped";
  const thead = document.createElement("thead");
  const htr = document.createElement("tr");
  vars.forEach((v) => {
    const th = document.createElement("th");
    th.textContent = v.Label || v.Name;
    htr.appendChild(th);
  });
  thead.appendChild(htr);
  const tbody = document.createElement("tbody");
  const maxRows = 250;
  rows.slice(0, maxRows).forEach((r) => {
    const tr = document.createElement("tr");
    r.forEach((cell) => {
      const td = document.createElement("td");
      // Format simple numbers with thin spaces as thousands sep
      const num = Number(cell);
      if (!Number.isNaN(num) && /^(?:-?\d{1,3}(?:[\d]*)?(?:\.\d+)?)$/.test(String(cell))) {
        td.textContent = num.toLocaleString("da-DK");
        td.style.textAlign = "right";
      } else {
        td.textContent = cell;
      }
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });
  table.appendChild(thead);
  table.appendChild(tbody);
  tblWrap.appendChild(table);
  holder.appendChild(tblWrap);

  const metaP = document.createElement("p");
  metaP.className = "muted";
  metaP.textContent = `Rækker vist: ${Math.min(rows.length, 250)} af ${rows.length}`;
  holder.appendChild(metaP);

  // AI comment
  try {
    const commentRes = await fetch("/api/ai/comment", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        question: document.getElementById("aiQuestion").value.trim(),
        previousAnswer: previousAnswerText || "",
        table: ex.table,
        params: ex.params,
        variables: vars,
        sample: rows.slice(0, 80),
      }),
    }).then((r) => r.json());
    if (commentRes?.comment) {
      const note = document.createElement("p");
      note.textContent = commentRes.comment;
      holder.appendChild(note);
    }
  } catch {}
}

// ---------- Chart rendering and view switch ----------
function prepareViewSwitch(vars, rows) {
  const viewSel = document.getElementById("viewType");
  const chartWrap = document.getElementById("chartContainer");
  const tableWrap = document.getElementById("tableContainer");
  const dlBtn = document.getElementById("downloadChart");

  function inferChartData() {
    const labelsIdx = inferLabelColumnIndex(vars, rows);
    const valueIdx = inferValueColumnIndex(vars, rows, labelsIdx);
    const labels = rows.map((r) => String(r[labelsIdx]));
    const values = rows.map((r) => Number(r[valueIdx]));
    return { labels, values };
  }

  function renderChart(kind) {
    if (state.chart) { state.chart.destroy(); state.chart = null; }
    const { labels, values } = inferChartData();
    const ctx = document.getElementById("dataChart");
    state.chart = new Chart(ctx, {
      type: kind === "line" ? "line" : kind === "pie" ? "pie" : "bar",
      data: {
        labels,
        datasets: [{
          label: "Værdi",
          data: values,
          backgroundColor: kind === "line" ? "rgba(54, 162, 235, 0.2)" : "rgba(54, 162, 235, 0.5)",
          borderColor: "rgba(54, 162, 235, 1)",
          borderWidth: 1,
          tension: 0.2,
        }],
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: kind === "pie" } } },
    });
  }

  function updateView() {
    const kind = viewSel.value;
    if (kind === "table") {
      chartWrap.hidden = true;
      tableWrap.hidden = false;
      dlBtn.hidden = true;
    } else {
      tableWrap.hidden = true;
      chartWrap.hidden = false;
      renderChart(kind);
      dlBtn.hidden = false;
    }
  }

  // Ensure container has a height when chart is visible
  chartWrap.style.minHeight = "340px";
  viewSel.onchange = updateView;
  dlBtn.onclick = () => {
    if (!state.chart) return;
    const url = state.chart.toBase64Image();
    const a = document.createElement("a");
    a.href = url;
    a.download = "diagram.png";
    a.click();
  };
  updateView();
}

function inferLabelColumnIndex(vars, rows) {
  // Prefer a time-like column
  const idx = vars.findIndex((v) => /peri|period|time|måned|kvartal|år/i.test(v.Name || v.Label || ""));
  if (idx >= 0) return idx;
  // Try value-like pattern in data
  for (let c = 0; c < (vars?.length || 0); c++) {
    const sample = String(rows?.[0]?.[c] ?? "");
    if (/^\d{4}(?:M\d{2}|Q\d|Y)?$/.test(sample)) return c;
  }
  return 0;
}

function inferValueColumnIndex(vars, rows, avoidIdx = -1) {
  const numericCols = [];
  for (let c = 0; c < (vars?.length || 0); c++) {
    if (c === avoidIdx) continue;
    const sample = Number(rows?.[0]?.[c]);
    if (!Number.isNaN(sample)) numericCols.push(c);
  }
  if (numericCols.length) return numericCols[numericCols.length - 1];
  return Math.max(0, Math.min((vars?.length || 1) - 1, 1));
}
