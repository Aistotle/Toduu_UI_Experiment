import "dotenv/config";
import express from "express";
import path from "node:path";
import fs from "node:fs";
import { GoogleGenerativeAI } from "@google/generative-ai";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3000;
const JOBINDSATS_TOKEN = process.env.JOBINDSATS_TOKEN;
const API_BASE = "https://api.jobindsats.dk/v2";
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || "";
const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-1.5-flash";
const HF_TOKEN = process.env.HUGGINGFACE_API_TOKEN || "";
const HF_EMBED_MODEL = process.env.HUGGINGFACE_EMBED_MODEL || "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2";

if (!JOBINDSATS_TOKEN) {
  console.warn("[warn] JOBINDSATS_TOKEN is not set. Set it in your environment or .env file.");
}

const app = express();

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));

// Load cheatsheet to help the model plan
let CHEATSHEET = "";
try {
  const p = path.join(__dirname, "..", "jobindsats-api-cheatsheet.md");
  CHEATSHEET = fs.readFileSync(p, "utf8");
} catch {}

// Load curated concept library (config/concepts.json)
try {
  const cp = path.join(__dirname, "..", "config", "concepts.json");
  if (fs.existsSync(cp)) {
    concepts = JSON.parse(fs.readFileSync(cp, "utf8"));
  }
} catch (e) {
  console.warn("[warn] Could not load concepts.json:", e.message);
}

// Simple caches
let subjectsCache = null; // [{SubjectID, SubjectName}]
let tablesCache = null;   // [{TableID, TableName, SubjectID, ...}]
let tableIndex = null;    // Map of tableId -> searchable text and weights
let concepts = [];        // Curated concept → tables mapping

async function getSubjects() {
  if (subjectsCache) return subjectsCache;
  const r = await forwardGet(`${API_BASE}/subjects/json`);
  subjectsCache = await r.json();
  return subjectsCache;
}

async function getAllTables() {
  if (tablesCache) return tablesCache;
  const r = await forwardGet(`${API_BASE}/tables/json`);
  tablesCache = await r.json();
  buildTableIndex(tablesCache);
  return tablesCache;
}

function normalize(s) {
  return String(s || "")
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "") // strip accents
    .replace(/æ/g, "ae").replace(/ø/g, "oe").replace(/å/g, "aa");
}

function tokenize(s) {
  return normalize(s).split(/[^\p{L}\p{N}]+/u).filter(Boolean);
}

const SYNONYMS = {
  'arbejdsloeshed': ['arbejdsloes', 'arbejdsloeshed', 'arbejdsloshed', 'arbejdslos', 'ledig', 'ledighed', 'ledige'],
  'a-dagpenge': ['a-dagpenge','dagpenge'],
};

function expandLabelVariants(words = []) {
  const out = new Set();
  for (const w of words) {
    const n = normalize(w);
    out.add(n);
    out.add(n.replace(/-/g, ''));
    out.add(n.replace(/\s+/g, ''));
  }
  return Array.from(out);
}

function matchConcepts(question) {
  const qn = normalize(question);
  const hits = [];
  for (const c of concepts) {
    const labels = expandLabelVariants(c.labels || []);
    const score = labels.reduce((acc, lab) => acc + (qn.includes(lab) ? lab.length : 0), 0);
    if (score > 0) hits.push({ concept: c, score });
  }
  if (!hits.length && (SYNONYMS['arbejdsloeshed'] || []).some((k) => qn.includes(k))) {
    const c = concepts.find((x) => x.id === 'arbejdsloeshed');
    if (c) hits.push({ concept: c, score: 1 });
  }
  hits.sort((a, b) => b.score - a.score);
  return hits.map((h) => h.concept);
}

function buildTableIndex(tables) {
  tableIndex = new Map();
  for (const t of tables) {
    const id = String(t.TableID);
    const parts = [];
    if (t.TableName) parts.push({ text: t.TableName, w: 3 });
    if (t.SubjectName) parts.push({ text: t.SubjectName, w: 2 });
    if (Array.isArray(t.Measurements)) for (const m of t.Measurements) parts.push({ text: m.Name, w: 2 });
    if (Array.isArray(t.Dimensions)) for (const d of t.Dimensions) parts.push({ text: d.DimensionName, w: 1 });
    tableIndex.set(id.toLowerCase(), parts);
  }
}

function scoreTable(t, tokens) {
  if (!tableIndex) return 0;
  const parts = tableIndex.get(String(t.TableID).toLowerCase());
  if (!parts) return 0;
  let s = 0;
  for (const { text, w } of parts) {
    const nt = normalize(text);
    for (const tok of tokens) if (nt.includes(tok)) s += w;
  }
  return s;
}

// Optional: lightweight semantic reranker via HuggingFace Inference API
async function embedBatch(texts) {
  const url = `https://api-inference.huggingface.co/pipeline/feature-extraction/${encodeURIComponent(HF_EMBED_MODEL)}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${HF_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(texts.length === 1 ? texts[0] : texts),
  });
  if (!res.ok) throw new Error(`HF ${res.status}`);
  const data = await res.json();
  // API returns [dim] for single input or [[dim], [dim], ...] for batch
  return Array.isArray(data[0]) ? data : [data];
}

function cosine(a, b) {
  let dot = 0, na = 0, nb = 0;
  for (let i = 0; i < a.length && i < b.length; i++) { dot += a[i]*b[i]; na += a[i]*a[i]; nb += b[i]*b[i]; }
  return dot / (Math.sqrt(na) * Math.sqrt(nb) + 1e-9);
}

async function latestYearLabelForTable(tableId) {
  try {
    const url = `${API_BASE}/data/${encodeURIComponent(tableId)}/json?period=l(Y:1)&area=${encodeURIComponent('Hele landet')}`;
    const r = await forwardGet(url);
    const payload = await r.json();
    const root = Array.isArray(payload) ? payload[0] : payload;
    const row = Array.isArray(root?.Data) && root.Data[0];
    if (Array.isArray(row)) {
      const periodIdx = (root.Variables || []).findIndex(v=>v.Name==='period');
      return periodIdx >= 0 ? row[periodIdx] : null;
    }
    return null;
  } catch { return null; }
}

function extractYearRange(question) {
  const q = normalize(question);
  const since = q.match(/siden\s+(\d{4})/);
  if (since) {
    const start = parseInt(since[1], 10);
    if (start >= 1990 && start <= 2100) return { mode: 'range', startYear: start };
  }
  const lastN = q.match(/seneste\s+(\d{1,3})\s*a/); // e.g. "seneste 5 år"
  if (lastN) return { mode: 'latest', n: Math.max(1, Math.min(60, parseInt(lastN[1], 10))) };
  return null;
}

function quickResolve(question, subjects, tables) {
  const q = normalize(question);
  const toks = new Set(tokenize(question));
  const include = (arr) => arr.some((k) => q.includes(k));

  const results = [];

  // 1) Concept library first
  const matchedConcepts = matchConcepts(question);
  if (matchedConcepts.length) {
    const concept = matchedConcepts[0];
    for (const tinfo of concept.tables || []) {
      const t = tables.find((tt) => String(tt.TableID).toLowerCase() === String(tinfo.id).toLowerCase());
      if (!t) continue;
      const params = Object.assign({ area: 'Hele landet' }, tinfo.defaults || {});
      const range = extractYearRange(question);
      const yearMention = q.includes('aar') || q.includes('aarsvis') || q.includes('aar for aar') || q.includes('aarligt');
      if (range?.mode === 'range') {
        const lastFullYear = new Date().getFullYear() - 1;
        params.period = `r(Y:${range.startYear}Y01-${lastFullYear}Y01)`;
      } else if (yearMention) {
        if (!/^l\(Y:/.test(params.period || '')) params.period = 'l(Y:10)';
      }
      const pct = q.includes('pct') || q.includes('procent');
      if (pct && String(tinfo.id).toLowerCase() === 'y25i01') params.measurement = 'memby25i01_1';
      if (q.includes('kvinde')) params._kon = 'Kvinder';
      else if (q.includes('maend') || q.includes('mand')) params._kon = 'Mænd';
      results.push({ tableId: t.TableID, reason: `Koncept: ${concept.id}`, params });
    }
  }

  if (results.length) return results;

  // Fallback: semantic search top-2
  const tokens = Array.from(toks);
  const prelim = [...tables].map((t) => ({ t, s: scoreTable(t, tokens) }))
    .sort((a,b) => b.s - a.s)
    .slice(0, 50)
    .filter((r) => r.s > 0);

  // If we have a HuggingFace token, rerank prelim via embeddings (multilingual)
  if (HF_TOKEN && prelim.length) {
    try {
      const qEmbed = (await embedBatch([question]))[0];
      const texts = prelim.map((r) => `${r.t.TableName} — ${r.t.SubjectName || ''}`);
      const embeds = await embedBatch(texts);
      const scored = prelim.map((r, i) => ({ r, c: cosine(qEmbed, embeds[i]) }))
        .sort((a,b) => b.c - a.c)
        .slice(0, 3)
        .map((x) => x.r.t);
      return scored.map((t) => ({ tableId: t.TableID, reason: 'Semantisk match (HF)', params: { period: 'l(M:12)', area: 'Hele landet' } }));
    } catch (e) {
      // fall through to lexical
    }
  }

  const ranked = prelim.slice(0, 3).map((r) => r.t);
  return ranked.map((t) => ({ tableId: t.TableID, reason: 'Semantisk match', params: { period: 'l(M:12)', area: 'Hele landet' } }));
}

function matchSubjectIdByName(name, subjects) {
  if (!name) return null;
  const n = String(name).toLowerCase();
  const hit = subjects.find((s) => s.SubjectName.toLowerCase().includes(n));
  return hit ? hit.SubjectID : null;
}

function resolveTableId(pref, tables, subjectId = null) {
  if (!pref) return null;
  const pool = subjectId ? tables.filter((t) => String(t.SubjectID) === String(subjectId)) : tables;
  // Try exact TableID (case-insensitive)
  let hit = pool.find((t) => String(t.TableID).toLowerCase() === String(pref).toLowerCase());
  if (hit) return hit.TableID;
  // Try by TableName contains
  const q = String(pref).toLowerCase();
  hit = pool.find((t) => t.TableName && t.TableName.toLowerCase().includes(q));
  return hit ? hit.TableID : null;
}

async function getTableDetail(id) {
  const r = await forwardGet(`${API_BASE}/tables/${encodeURIComponent(id)}/json`);
  const arr = await r.json();
  return Array.isArray(arr) ? arr[0] : arr;
}

async function getDataJson(id, params) {
  const qs = new URLSearchParams(params || {});
  const url = `${API_BASE}/data/${encodeURIComponent(id)}/json${qs.toString() ? `?${qs.toString()}` : ""}`;
  const r = await forwardGet(url);
  const data = await r.json();
  return { url, payload: data };
}

// Simple health/status
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", tokenConfigured: Boolean(JOBINDSATS_TOKEN), aiReady: Boolean(GEMINI_API_KEY) });
});

// Helper to forward GET to Jobindsats API
async function forwardGet(url) {
  const res = await fetch(url, {
    headers: { Authorization: JOBINDSATS_TOKEN || "" },
  });
  if (!res.ok) {
    const text = await res.text();
    console.warn('[upstream-error]', res.status, url, text?.slice(0,180));
    const err = new Error(`Upstream ${res.status}`);
    err.status = res.status;
    err.body = text;
    throw err;
  }
  return res;
}

// ---------- AI: plan + execute ----------
const genAI = GEMINI_API_KEY ? new GoogleGenerativeAI(GEMINI_API_KEY) : null;

function parseJsonLoose(text) {
  try { return JSON.parse(text); } catch {}
  // Try to extract first JSON object block
  const m = text.match(/\{[\s\S]*\}/);
  if (m) {
    try { return JSON.parse(m[0]); } catch {}
  }
  return null;
}

function aiPlanSystemPrompt() {
  return [
    "You are a precise data planner for Denmark's Jobindsats API.",
    "Goal: Given a user question, propose up to 4 concrete data queries to the API that help answer it.",
    "Respect the API usage from cheatsheet. Always include period and area. Use valid dimension keys when possible.",
    "Prefer small, recent slices (e.g., l(M:12)) and 'Hele landet' unless the question requests specific areas.",
    "If unsure of exact TableID, include a descriptive tableNameContains and/or subjectName.",
    "Respond ONLY as compact JSON with fields: {queries: [...], notes: string}. No code fences, no markdown."
  ].join("\n");
}

function aiAnswerSystemPrompt() {
  return [
    "You are a concise analyst.",
    "Given the user's question and fetched datasets (variables and data rows), write a short, clear answer in Danish.",
    "Cite source table IDs inline like (Y01A02). Mention periods/areas used and any assumptions.",
    "Return ONLY JSON: {finalAnswer: string, assumptions?: string, caveats?: string}. No code fences, no markdown."
  ].join("\n");
}

function buildPlanUserPrompt(question) {
  return `Brugerens spørgsmål:\n${question}\n\nTilgængelig API (cheatsheet):\n${CHEATSHEET.slice(0, 8000)}\n\nJSON-format:\n{\n  "queries": [\n    {\n      "tableId": "Y01A02", // foretrukket, hvis kendt\n      "tableNameContains": "Antal personer", // alternativ hvis tableId ukendt\n      "subjectName": "A-dagpenge", // valgfri til afgrænsning\n      "reason": "Hvorfor er tabellen relevant",\n      "params": {\n        "period": "l(M:12)",\n        "area": "Hele landet",\n        "_kon": "*",\n        "measurement": "measa02_1" // hvis relevant\n      }\n    }\n  ],\n  "notes": "kort begrundelse"\n}`;
}

app.post("/api/ai/ask", async (req, res) => {
  try {
    if (!genAI) return res.status(400).json({ error: "Gemini API key missing (set GEMINI_API_KEY)" });
    const question = String(req.body?.question || "").trim();
    if (!question) return res.status(400).json({ error: "Missing question" });

    // Ensure catalog present
    const [subjects, tables] = await Promise.all([getSubjects(), getAllTables()]);

    // 1) Quick resolver (deterministic, fast, robust)
    let quick = quickResolve(question, subjects, tables);

    // If quick resolver proposes something, we use that and only use AI for wording the final answer.
    let plan = { queries: quick, notes: quick.length ? "quick" : "" };

    // Otherwise: Ask Gemini to plan
    if (!plan.queries.length) {
      const model = genAI.getGenerativeModel({ model: GEMINI_MODEL });
      const planResp = await model.generateContent([
        { text: aiPlanSystemPrompt() },
        { text: buildPlanUserPrompt(question) },
      ]);
      const planText = planResp.response.text();
      plan = parseJsonLoose(planText) || { queries: [], notes: "" };
      if (!Array.isArray(plan.queries)) plan.queries = [];
      if (!plan.notes) plan.notes = "";
    }

    // 1b) Heuristic rescue plan if empty
    if (plan.queries.length === 0) {
      const ql = question.toLowerCase();
      const numMatch = ql.match(/seneste\s+(\d{1,3})/);
      const months = numMatch ? Math.min(499, Math.max(1, parseInt(numMatch[1], 10))) : 12;
      const picks = [];
      // prefer subjects mentioned by name
      const subjHits = subjects.filter((s) => ql.includes(s.SubjectName.toLowerCase()));
      const subjectIds = subjHits.map((s) => s.SubjectID);
      const pool = subjectIds.length ? tables.filter((t) => subjectIds.includes(t.SubjectID)) : tables;
      // score by name keyword overlap
      const tokens = ql.split(/[^\p{L}\p{N}\-]+/u).filter(Boolean);
      function score(t) {
        const name = (t.TableName || "").toLowerCase();
        let s = 0;
        for (const tok of tokens) if (name.includes(tok)) s += 1;
        return s;
      }
      const ranked = [...pool].map((t) => ({ t, s: score(t) }))
        .sort((a, b) => b.s - a.s || String(a.t.TableID).localeCompare(String(b.t.TableID)));
      for (const r of ranked.slice(0, 3)) {
        if (!r.t || r.s === 0) continue;
        picks.push({ tableId: r.t.TableID, reason: `Heuristisk match på '${r.s}' nøgleord`, params: { period: `l(M:${months})`, area: "Hele landet" } });
      }
      if (!picks.length) picks.push({ tableId: "Y01A02", reason: "fallback", params: { period: `l(M:${months})`, area: "Hele landet" } });
      plan.queries = picks;
      plan.notes = (plan.notes || "") + " (heuristic)";
    }

    // 2) Resolve plan -> concrete tables and params
    const resolved = [];
    for (const q of (plan.queries || []).slice(0, 4)) {
      // try tableId then name/subject
      let sid = null;
      if (q.subjectName) sid = matchSubjectIdByName(q.subjectName, subjects);
      const pref = q.tableId || q.tableNameContains;
      const tableId = resolveTableId(pref, tables, sid);
      if (!tableId) continue;
      const params = Object.assign({ period: "l(M:12)", area: "Hele landet" }, q.params || {});
      // Coerce arrays to comma strings
      const normalized = {};
      for (const [k, v] of Object.entries(params)) {
        if (v == null || v === "") continue;
        normalized[k] = Array.isArray(v) ? v.join(",") : String(v);
      }
      resolved.push({ tableId, reason: q.reason || "", params: normalized });
    }
    if (!resolved.length) {
      resolved.push({ tableId: "Y01A02", reason: "fallback", params: { period: "l(M:12)", area: "Hele landet", _kon: "*" } });
    }

    // 3) Fetch details + data for each query
    const executed = [];
    for (const r of resolved) {
      try {
        const detail = await getTableDetail(r.tableId);
        // If range asked with open-ended latest year, fix now using table detail
        if (r.params?.period && /^r\(Y:\d{4}Y01-9999Y01\)$/.test(r.params.period)) {
          const latestY = await latestYearLabelForTable(r.tableId) || `${new Date().getFullYear()}Y01`;
          r.params.period = r.params.period.replace('9999Y01', latestY);
        }
        const data = await getDataJson(r.tableId, r.params);
        executed.push({
          table: { id: r.tableId, name: detail.TableName },
          reason: r.reason,
          params: r.params,
          detail,
          dataUrl: data.url,
          payload: data.payload,
        });
      } catch (e) {
        executed.push({ table: { id: r.tableId }, reason: r.reason, params: r.params, error: String(e.message || e) });
      }
    }

    // 4) Ask Gemini to compose the final answer based on fetched data
    const compactDatasets = executed.map((ex) => {
      const root = Array.isArray(ex.payload) ? ex.payload[0] : ex.payload;
      const sampleRows = Array.isArray(root?.Data) ? root.Data.slice(0, 40) : [];
      return {
        tableId: ex.table?.id,
        tableName: ex.table?.name,
        variables: root?.Variables,
        data: sampleRows,
        params: ex.params,
      };
    });

    const answerResp = await model.generateContent([
      { text: aiAnswerSystemPrompt() },
      { text: `Spørgsmål:\n${question}` },
      { text: `Datasæt (truncate):\n${JSON.stringify(compactDatasets).slice(0, 120000)}` },
    ]);
    const answer = parseJsonLoose(answerResp.response.text()) || { finalAnswer: answerResp.response.text() };

    res.json({ plan, resolved, executed: executed.map(({ payload, ...rest }) => rest), answer });
  } catch (err) {
    console.error("/api/ai/ask error", err);
    res.status(500).json({ error: err.message || String(err) });
  }
});

// AI: short table comment for non-experts
function aiCommentPrompt() {
  return [
    "You are a helpful analyst.",
    "Given user's question, a prior short answer, and one dataset (Variables and sample rows), write a one-to-two sentence explanation in Danish to help non-experts understand the table.",
    "Mention time span and area if possible. Be concrete and avoid hedging.",
    "Respond ONLY JSON: {comment: string}. No markdown, no code fences.",
  ].join("\n");
}

app.post("/api/ai/comment", async (req, res) => {
  try {
    if (!genAI) return res.status(400).json({ error: "Gemini API key missing (set GEMINI_API_KEY)" });
    const { question = "", previousAnswer = "", table = {}, params = {}, variables = [], sample = [] } = req.body || {};
    const model = genAI.getGenerativeModel({ model: GEMINI_MODEL });
    const msg = [
      { text: aiCommentPrompt() },
      { text: `Spørgsmål: ${question}` },
      { text: `Tidligere svar: ${previousAnswer}` },
      { text: `Tabel: ${JSON.stringify(table)}` },
      { text: `Parametre: ${JSON.stringify(params)}` },
      { text: `Variables: ${JSON.stringify(variables)}` },
      { text: `Data (sample): ${JSON.stringify(sample)}` },
    ];
    const resp = await model.generateContent(msg);
    const parsed = parseJsonLoose(resp.response.text());
    if (parsed?.comment) return res.json({ comment: parsed.comment });
    return res.json({ comment: resp.response.text() });
  } catch (err) {
    res.status(500).json({ error: err.message || String(err) });
  }
});

// Debug: quick resolver output
app.get('/api/debug/quick', async (req, res) => {
  const q = String(req.query.q || '').trim();
  const [subjects, tables] = await Promise.all([getSubjects(), getAllTables()]);
  const out = quickResolve(q, subjects, tables);
  res.json({ q, out });
});

app.get('/api/debug/qa-plan', async (req, res) => {
  const question = String(req.query.q || '');
  const [subjects, tables] = await Promise.all([getSubjects(), getAllTables()]);
  const queries = quickResolve(question, subjects, tables);
  res.json({ question, queries });
});

// Concepts API (read-only)
app.get('/api/concepts', (req, res) => {
  res.json(concepts || []);
});
app.get('/api/concepts/match', (req, res) => {
  const q = String(req.query.q || '');
  res.json({ matches: matchConcepts(q) });
});

// Deterministic Q&A: fast planner (no LLM planning)
app.post('/api/qa/ask', async (req, res) => {
  try {
    const question = String(req.body?.question || '').trim();
    if (!question) return res.status(400).json({ error: 'Missing question' });
    const [subjects, tables] = await Promise.all([getSubjects(), getAllTables()]);
    let queries = quickResolve(question, subjects, tables);
    if (!queries.length) {
      // last resort: take top semantic match
      const tokens = tokenize(question);
      const ranked = [...tables].map((t) => ({ t, s: scoreTable(t, tokens) }))
        .sort((a,b)=>b.s-a.s).slice(0,2).filter(r=>r.s>0)
        .map((r)=>({ tableId: r.t.TableID, reason: 'Semantisk match', params: { period: 'l(M:12)', area: 'Hele landet' } }));
      queries = ranked;
    }
    if (!queries.length) {
      return res.status(404).json({ error: 'Ingen relevante tabeller fundet' });
    }
    // Resolve and execute
    const resolved = [];
    for (const q of queries.slice(0,4)) {
      try {
        const id = resolveTableId(q.tableId || q.tableNameContains, tables, null);
        if (!id) continue;
        const params = Object.assign({ period: 'l(M:12)', area: 'Hele landet' }, q.params || {});
        if (params.period && /^r\(Y:\d{4}Y01-9999Y01\)$/.test(params.period)) {
          const latestY = await latestYearLabelForTable(id) || `${new Date().getFullYear()}Y01`;
          params.period = params.period.replace('9999Y01', latestY);
        }
        const detail = await getTableDetail(id);
        const data = await getDataJson(id, params);
        resolved.push({
          table: { id, name: detail.TableName },
          reason: q.reason || '',
          params,
          detail,
          dataUrl: data.url,
          payload: data.payload,
        });
      } catch (e) {
        // skip invalid query
      }
    }
    if (!resolved.length) {
      // Fallback: unemployment yearly in whole country since 2015
      try {
        const id = 'y25i01';
        const lastFullYear = new Date().getFullYear() - 1;
        const params = { area: 'Hele landet', period: `r(Y:2015Y01-${lastFullYear}Y01)` };
        const detail = await getTableDetail(id);
        const data = await getDataJson(id, params);
        resolved.push({ table: { id, name: detail.TableName }, reason: 'fallback', params, detail, dataUrl: data.url, payload: data.payload });
      } catch (e) {
        return res.status(404).json({ error: 'Ingen resultater' });
      }
    }

    // Compose answer with Gemini (optional)
    let answer = { finalAnswer: '' };
    if (genAI) {
      const model = genAI.getGenerativeModel({ model: GEMINI_MODEL });
      const compact = resolved.map((ex)=>{
        const root = Array.isArray(ex.payload) ? ex.payload[0] : ex.payload;
        return { tableId: ex.table.id, tableName: ex.table.name, variables: root?.Variables, data: root?.Data?.slice(0,40), params: ex.params };
      });
      const r = await model.generateContent([
        { text: aiAnswerSystemPrompt() },
        { text: `Spørgsmål:\n${question}` },
        { text: `Datasæt (truncate):\n${JSON.stringify(compact).slice(0,120000)}` },
      ]);
      answer = parseJsonLoose(r.response.text()) || { finalAnswer: r.response.text() };
    }
    res.json({ plan: { queries, notes: 'quick-only' }, resolved: queries.map(q=>({ tableId: q.tableId, reason: q.reason, params: q.params })), executed: resolved.map(({payload, ...rest})=>rest), answer });
  } catch (err) {
    res.status(500).json({ error: err.message || String(err) });
  }
});

// Subjects
app.get("/api/subjects", async (req, res) => {
  try {
    const r = await forwardGet(`${API_BASE}/subjects/json`);
    const data = await r.json();
    res.json(data);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message, body: err.body });
  }
});

// Tables list (optionally filtered by subjectid(s))
app.get("/api/tables", async (req, res) => {
  try {
    const qs = new URLSearchParams();
    if (req.query.subjectid) qs.set("subjectid", String(req.query.subjectid));
    const url = `${API_BASE}/tables${qs.toString() ? `?${qs.toString()}` : ""}`;
    const r = await forwardGet(url);
    const data = await r.json();
    res.json(data);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message, body: err.body });
  }
});

// Table details with allowed values
app.get("/api/tables/:id", async (req, res) => {
  try {
    const id = encodeURIComponent(req.params.id);
    const url = `${API_BASE}/tables/${id}/json`;
    const r = await forwardGet(url);
    const data = await r.json();
    res.json(Array.isArray(data) ? data[0] : data);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message, body: err.body });
  }
});

// Data endpoint proxy: JSON or CSV via `format` query parameter
app.get("/api/data/:id", async (req, res) => {
  try {
    const id = encodeURIComponent(req.params.id);
    const { format, ...rest } = req.query;
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries(rest)) {
      if (Array.isArray(v)) {
        v.forEach((vv) => qs.append(k, String(vv)));
      } else if (v != null) {
        qs.set(k, String(v));
      }
    }
    const suffix = String(format).toLowerCase() === "csv" ? "csv" : "json";
    const url = `${API_BASE}/data/${id}/${suffix}${qs.toString() ? `?${qs.toString()}` : ""}`;
    const upstream = await forwardGet(url);
    if (suffix === "csv") {
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      const text = await upstream.text();
      res.send(text);
    } else {
      const data = await upstream.json();
      res.json(data);
    }
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message, body: err.body });
  }
});

// Serve static UI
app.use(express.static(path.join(__dirname, "..", "public")));

// Fallback to index.html for root
app.use((req, res, next) => {
  if (req.method !== "GET") return next();
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Jobindsats Explorer running on http://localhost:${PORT}`);
});
