Jobindsats Explorer
===================

Minimal webapp to browse Jobindsats API subjects, discover tables, inspect dimensions/allowed values, and run data queries — without the terminal.

Setup
-----

1) Create a `.env` file with your token:

```
JOBINDSATS_TOKEN=YOUR_TOKEN
PORT=3000
```

2) Install and run:

```
npm install
npm start
```

Open http://localhost:3000

Notes
-----

- The server proxies requests to `https://api.jobindsats.dk/v2` and injects `Authorization` from `JOBINDSATS_TOKEN` so your token never touches the browser.
- Use the sidebar to pick a subject, then a table. The details view shows measurements, areas, and dimensions. Build a query (latest or range) and fetch results.
- Results render as a table using the `Variables` header mapping from the API. Use “Download CSV” to get the same query as CSV.

AI Assistant (Gemini during testing)
-----------------------------------

- Set `GEMINI_API_KEY` (Google Generative AI) in `.env`. Optional `GEMINI_MODEL` (default `gemini-1.5-flash`).
- Use the “AI Assistent” box to ask questions in Danish. The server asks Gemini to propose relevant queries, executes them against the Jobindsats API, and composes an answer.
- The assistant returns the planned queries, exact data URLs, and a concise answer. Links let you open the same queries in the explorer or download CSV.

Concept Library + Semantic Matching
-----------------------------------

- Curated concepts live in `config/concepts.json` (see `CONCEPTS.md`). The server matches user text to concept labels (accent-insensitive), then picks preferred tables with sensible defaults.
- If no concept matches, a lexical search of table names/subjects/measurements runs. Optionally, set `HUGGINGFACE_API_TOKEN` to enable multilingual embedding reranking for better matches.
- Debug endpoints: `/api/concepts`, `/api/concepts/match?q=...`, `/api/debug/qa-plan?q=...`.

Switching to GPT-5
------------------

The AI route is modular — swap the model provider by replacing the Gemini client in `server/index.js` with a GPT-5 client and keep the same plan/answer prompts. The output contract is plain JSON, so the rest of the app stays unchanged.
