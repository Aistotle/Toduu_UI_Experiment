# Jobindsats API — Cheatsheet (VS Code-ready)

> **Formål:** Hurtig, praktisk guide til at opdage tabeller, forstå parametre/værdier og hente data direkte fra VS Code/CLI eller din egen GUI.  
> **Kort fortalt:** Brug rækken **/subjects → /tables → /tables/{id} → /data/{id}**. Alt er *ikke-case-sensitivt*. Format vælges med `/json` eller `/csv` til sidst.

---

## 1) Base-URL, version og auth
- Base: `https://api.jobindsats.dk`
- Version: altid `v2` → fx `https://api.jobindsats.dk/v2/…`
- Auth-header: `Authorization: <DIT_API_TOKEN>`
- HTTP-metoder: `GET` og `POST`
- Formater: JSON (default) eller CSV

**cURL-test**
```bash
curl --header "Authorization: <TOKEN>" https://api.jobindsats.dk/v2/subjects/json
```

---

## 2) Opdag data: subjects → tables → tables/{id}
### a) Emner (subjects)
Liste over emner (ydelsesgrupper m.m.):
```bash
GET /v2/subjects[/json|/csv]
```

### b) Målinger/tabeller (tables)
Alle tabeller – evt. filtrér på emne(r) med `subjectid`:
```bash
GET /v2/tables?subjectid=1123[,1474]
GET /v2/tables/json
```
**Responsen inkluderer bl.a.:**
- `TableID`, `TableName`
- `Measurements` (målevariable; brug disse i `measurement=`)
- `PeriodCategory` (M, Q, QMAT, Y, MYTD)
- `AreaHierarchy` (Hele landet, RAR, kommuner)
- `Dimensions` (hvilke dimensioner tabellen har)

### c) Info om en specifik tabel
Se *gyldige værdier* for `Area`, `Period` samt alle dimensioner + `DefaultValue`:
```bash
GET /v2/tables/{TableID}[/json|/csv]
# fx: /v2/tables/Y01A02/json
```

---

## 3) Hent data: /data/{TableID}
```bash
GET /v2/data/{TableID}[/json|/csv]?area=...&period=...&<dimensioner>&measurement=...
```
**Minimum:** `area` og `period`.  
**Typiske dimensioner:** begynder med underscore (fx `_kon`=køn, `_aldera`=alder).  
**Målevariable:** vælg specifik via `measurement=` (brug ID’er fra `Measurements` i `/tables`).

**Eksempler**
```bash
# Seneste 12 mdr., Hele landet, alle køn:
/v2/data/Y01A02/json?period=l(M:12)&area=Hele landet&_kon=*

# Kvinder 25–29 år, antallet af personer (mgrpa02_1):
/v2/data/Y01A02/json?period=l(M:3)&area=Hele landet&_kon=Kvinder&_aldera=25-29 år&measurement=mgrpa02_1

# Flere områder + range:
/v2/data/Y01A02/csv?period=r(M:2023M01-2023M12)&area=Hele landet,Aalborg&_kon=Mænd
```

> **Tip:** Biblioteker (fetch/axios/requests) URL-enkoder automatisk (mellemrum → `%20`). Hvis du skriver URL’en manuelt, brug `%20` i stedet for mellemrum: `Hele%20landet`.

---

## 4) Perioder — “latest” og “range”
- **Latest:** `period=l(<kategori>:N)` vælger de seneste N perioder. Eksempler:  
  - `l(M:10)` → 10 måneder  
  - `l(Q:4)` → 4 kvartaler  
  - `l(QMAT:3)` → 3 glidende 4-kvartalers perioder  
  - `l(Y:5)` → 5 år  
  - `l(MYTD03:3)` → “Month Year-To-Date” varianter
- **Range:** `period=r(<kategori>:START-END)`  
  - `r(M:2023M01-2023M12)`, `r(Q:2019Q03-2020Q04)`, `r(Y:2019Y01-2024Y01)`
- “latest” understøtter op til **499** perioder.

> **Kategorier:** `M` (måned), `Q` (kvartal), `QMAT` (glidende 4 kvartaler), `Y` (år), `MYTD` (Month Year-To-Date).

---

## 5) Områder og massevalg
- **Alle RAR-områder:** `area=RAR` (inkl. Hele landet implicit)
- **Alle kommuner:** `area=!RAR` (Hele landet medtages implicit)
- **Wildcard:** en dimensions fulde udfaldsrum: `_kon=*`
- **Ekskludér værdier:** `!` foran de uønskede:  
  `_aldera=!16-19 år,20-24 år` (alle aldre **undtagen** disse)
- **Værdier med komma:** brug apostrof:  
  `_akassedp='A-kassen for Journalistik, Komm. og Sprog','Ase'`

---

## 6) Defaults, cases og format
- **Ikke-case-sensitivt:** `y01a02 == Y01A02` (gælder parametre og værdier).
- **DefaultValue:** hvis du udelader en dimension, bruges dens `DefaultValue` (ses i `/tables/{id}`).
- **Formatvalg:** tilføj `/json` eller `/csv` i endpointet. CSV har `;` som separator og `,` som decimal.

---

## 7) POST-kald (godt til mange værdier)
Gem din forespørgsel som JSON og send den i POST (praktisk hvis mange værdier):
```json
{
  "period": ["2021M10"],
  "area": ["Hele landet","Aalborg","Odense"],
  "_kon": ["Kvinder","Mænd"],
  "_aldera": ["25-29 år","30-34 år"]
}
```
**cURL**
```bash
curl -X POST -d "@query.json" -H "Authorization: <TOKEN>" \
"https://api.jobindsats.dk/v2/data/Y01A02/csv" --output Y01A02.csv
```

---

## 8) Praktiske grænser og faldgruber
- **Timeouts:** Meget store kald (≈ **>200.000 celler**) kan time out. Del op i mindre kald.
- **Diskretionering:** Du kan ikke bare summere “lodret” på tværs af dimensioner og forvente korrekte totals.
- **Levende data:** Re-træk historiske perioder ved behov (data opdateres løbende).
- **Mind celler:** Brug `subjectid`-filter i `/tables`, `latest`/`range`, og snævre dimensioner.

---

## 9) “Kend dine nøgler” (eksempler pr. tabel)
Dimensioners navne varierer pr. tabel. Tjek altid `/tables/{id}` for præcise nøgler og værdier.
- `_kon` → Køn (`Køn i alt`, `Kvinder`, `Mænd`)
- `_aldera` → Alder (fx `25-29 år`)
- `_oprinda` → Herkomst (`Herkomst i alt`, m.fl.)
- `_akassedp` → A-kasse (vær OBS på komma i enkelte navne → apostrof)

---

## 10) Hurtige kodeeksempler (VS Code)

### Node.js (native `fetch` i Node ≥18)
```js
// hent.js
const url = "https://api.jobindsats.dk/v2/data/Y01A02/json?period=l(M:6)&area=Hele%20landet&_kon=*";
const res = await fetch(url, { headers: { Authorization: process.env.JOBINDSATS_TOKEN } });
if (!res.ok) throw new Error(`HTTP ${res.status}`);
const data = await res.json();
console.log(data);
```

Kør:
```bash
export JOBINDSATS_TOKEN="<TOKEN>"
node hent.js
```

### Python (requests + CSV→DataFrame)
```python
import requests
from io import StringIO
import pandas as pd

u = "https://api.jobindsats.dk/v2/data/Y01A02/csv?period=l(M:12)&area=Hele%20landet&_kon=*"
r = requests.get(u, headers={"Authorization": "<TOKEN>"})
r.raise_for_status()
df = pd.read_csv(StringIO(r.text), sep=";", decimal=",")
print(df.head())
```

---

## 11) Fejlsøgning (tjekliste)
- **400/404:** Manglende/ukorrekt `TableID`, dimension-nøgle eller værdi.
- **401:** Manglende eller forkert `Authorization` header.
- **Tomt svar:** For snæver filtrering eller forkert dimension. slå værdier op i `/tables/{id}`.
- **Encoding:** Er mellemrum/æøå URL-enkodet? (eller lad dit HTTP-bibliotek gøre det automatisk)
- **For stort kald:** Brug `latest`/`range` eller split områder/dimensioner op.

---

## 12) Copy-paste URL-skabeloner

**Seneste 3 mdr., Hele landet, alle køn**
```
/v2/data/Y01A02/json?period=l(M:3)&area=Hele landet&_kon=*
```

**Range for 2023, Hele landet + Aalborg, mænd**
```
/v2/data/Y01A02/csv?period=r(M:2023M01-2023M12)&area=Hele landet,Aalborg&_kon=Mænd
```

**Ekskludér aldersgrupper (alle undtagen 16–24 år)**
```
/v2/data/Y01A02/json?period=l(M:6)&area=Hele landet&_aldera=!16-19 år,20-24 år
```

**Vælg specifik målevariabel (fx Antal personer = mgrpa02_1)**
```
/v2/data/Y01A02/json?period=l(M:6)&area=Hele landet&measurement=mgrpa02_1
```

---

## 13) Mental model (så du altid kan finde “ordene”)
1. **Find tabel** med `/tables` (evt. på `subjectid`).  
2. **Læs værdier** i `/tables/{id}` (Area, Period, hver dimensions `Values`, samt `Measurements`).  
3. **Byg kald** til `/data/{id}` med præcis de værdier du fandt.  
4. **Trim kaldet** (latest/range, wildcard/udeluk, CSV/JSON).  
5. **Iterér** (split store kald; gem nøgler du bruger ofte i din GUI).


