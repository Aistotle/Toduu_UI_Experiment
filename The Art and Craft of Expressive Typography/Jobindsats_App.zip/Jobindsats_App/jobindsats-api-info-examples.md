Jobindsats API – Cheatsheet with examples (PTVC02, PTVC03, Y14D03)

Goal: Pull the right numbers fast — stock (people in activation), flow (starts/ends), and quarterly outcomes.

⸻

0) Auth (simple & safe)

export JOBINDSATS_TOKEN="YOUR_TOKEN_HERE"
# All requests:
# -H "Authorization: $JOBINDSATS_TOKEN"

Quick test:

curl -H "Authorization: $JOBINDSATS_TOKEN" \
"https://api.jobindsats.dk/v2/subjects/json"


⸻

1) Discover what’s available

Subjects:

curl -H "Authorization: $JOBINDSATS_TOKEN" \
"https://api.jobindsats.dk/v2/subjects/json"

Table metadata (periods, dimensions, measurements):

curl -H "Authorization: $JOBINDSATS_TOKEN" \
"https://api.jobindsats.dk/v2/tables/PTVC03/json"


⸻

2) Period categories (critical per table)
	•	PTVC02 — Antal aktiverede og forløb (STOCK): M, Q, Y
	•	PTVC03 — Påbegyndte/afsluttede (FLOW): M, Q, QMAT, Y
	•	Y14D03 — Virksomhedsrettede tilbud og efterfølgende beskæftigelse: Q, QMAT, Y (no monthly)

Latest & Range syntax (URL-encoded):
	•	Latest: period=l%28M%3A6%29  ← this is l(M:6)
	•	Range:  period=r(M:2025M01-2025M06)

For Y14D03 use Q or QMAT, e.g. l%28Q%3A6%29.

⸻

3) STOCK — “How many are in praktik this month?” (PTVC02)

Aarhus, Kontanthjælp, 30+, Virksomhedspraktik i alt, latest 6 months (CSV):

curl -H "Authorization: $JOBINDSATS_TOKEN" \
-o ~/Downloads/aarhus_ptvc02_stock.csv \
"https://api.jobindsats.dk/v2/data/PTVC02/csv?area=Aarhus&period=l%28M%3A6%29&_ygrpc02=Kontanthj%C3%A6lp&_aldera=!16-19%20%C3%A5r,20-24%20%C3%A5r,25-29%20%C3%A5r&_tilb_2ptv=Virksomhedspraktik+i+alt&measurement=measc01_1"

Notes:
	•	measurement=measc01_1 = Antal aktiverede (persons)
	•	measurement=measc02_1 = Antal aktiveringsforløb (often noisier — people can have >1)

⸻

4) FLOW — “How many start/finish?” (PTVC03, monthly)

Aarhus, Kontanthjælp, Virksomhedspraktik i alt, latest 6 months:

curl -H "Authorization: $JOBINDSATS_TOKEN" \
-o ~/Downloads/aarhus_ptvc03_flow.csv \
"https://api.jobindsats.dk/v2/data/PTVC03/csv?area=Aarhus&period=l%28M%3A6%29&_ygrpc03=Kontanthj%C3%A5lp&_tilb_2ptv=Virksomhedspraktik+i+alt"

Common measurements in PTVC03 (check your /tables/PTVC03/json to confirm exact IDs):
	•	mgrpc03_1 = Påbegyndte forløb
	•	mgrpc03_2 = Antal forløb primo
	•	mgrpc03_3 = Afsluttede forløb
	•	mgrpc03_4 = Antal forløb ultimo

Example: only starts as one column:

...&measurement=mgrpc03_1

Split by age or ydelsesgrupper as needed (dimension IDs in metadata).

⸻

5) FLOW/Outcomes — Virksomhedsrettede tilbud (Y14D03, quarterly)

Y14D03 does not support monthly. Use Q, QMAT, or Y.

Aarhus, Kontanthjælp, Virksomhedspraktik i alt, latest 6 quarters:

curl -H "Authorization: $JOBINDSATS_TOKEN" \
-o ~/Downloads/aarhus_y14d03_Q.csv \
"https://api.jobindsats.dk/v2/data/Y14D03/csv?area=Aarhus&period=l%28Q%3A6%29&_ygrpmm12=Kontanthj%C3%A6lp&_tilbud_d03=Virksomhedspraktik+i+alt&_brancheb=Branche+i+alt"

Add målgrupper:

...&_maalgrp_d03=Jobparate+mv.,Aktivitetsparate+mv.

Add varighed (start wide, narrow later):

...&_varig_d03=I+alt     # later: 2-4+uger, 5-13+uger, ...


⸻

6) URL encoding (tiny but important)
	•	Parentheses in period must be encoded:
l(M:6) → l%28M%3A6%29
l(Q:6) → l%28Q%3A6%29
	•	Spaces → %20 (or +)
	•	æ/ø/å must be encoded (Kontanthjælp → Kontanthj%C3%A6lp)

⸻

7) Quick benchmarks

Hele landet:

area=Hele%20landet

Latest 12 months/quarters:

period=l%28M%3A12%29   or   period=l%28Q%3A12%29


⸻

8) Typical errors (and fixes)
	•	“L(M:6) is not valid” → use lowercase l and URL-encode parentheses; or use a valid period category for that table (Y14D03 → Q/QMAT/Y).
	•	401 / “missing key” → header must be Authorization: <token> (no Bearer, no x-api-key).
	•	Tiny/empty CSV (~40–80 bytes) → filters too narrow. Start without varighed/målgrupper; add them one by one.
	•	Wrong measurement → add measurement= based on the table’s Measurements in metadata.

⸻

9) Minimal workflow
	1.	Stock (PTVC02): how many are in praktik this month (persons)
	2.	Flow (PTVC03): how many start/finish each month
	3.	Quarterly outcomes (Y14D03): virksomhedsrettede offers with splits (målgruppe, varighed, branche)
	4.	Plot: bars = starts (flow), line = in aktivation (stock)

⸻

10) Copy-paste mini-templates

PTVC02 (stock, M:6):

curl -H "Authorization: $JOBINDSATS_TOKEN" -o ~/Downloads/ptvc02_stock.csv \
"https://api.jobindsats.dk/v2/data/PTVC02/csv?area=Aarhus&period=l%28M%3A6%29&_ygrpc02=Kontanthj%C3%A6lp&_tilb_2ptv=Virksomhedspraktik+i+alt&measurement=measc01_1"

PTVC03 (flow starts only, M:6):

curl -H "Authorization: $JOBINDSATS_TOKEN" -o ~/Downloads/ptvc03_flow.csv \
"https://api.jobindsats.dk/v2/data/PTVC03/csv?area=Aarhus&period=l%28M%3A6%29&_ygrpc03=Kontanthj%C3%A6lp&_tilb_2ptv=Virksomhedspraktik+i+alt&measurement=mgrpc03_1"

Y14D03 (quarterly, Q:6):

curl -H "Authorization: $JOBINDSATS_TOKEN" -o ~/Downloads/y14d03_q.csv \
"https://api.jobindsats.dk/v2/data/Y14D03/csv?area=Aarhus&period=l%28Q%3A6%29&_ygrpmm12=Kontanthj%C3%A6lp&_tilbud_d03=Virksomhedspraktik+i+alt&_brancheb=Branche+i+alt"

