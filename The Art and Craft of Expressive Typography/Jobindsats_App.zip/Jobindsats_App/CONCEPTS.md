Concept Library (query → tables)
================================

Purpose
-------
Map everyday words and synonyms (Danish) to the most relevant Jobindsats tables so users don’t need exact IDs. The server consults this library first when planning queries.

Location
--------
`config/concepts.json`

Shape
-----

[
  {
    "id": "arbejdsloeshed",
    "labels": ["arbejdsløshed", "ledighed", "ledige"],
    "tables": [
      { "id": "y25i01", "note": "Ledighed antal/pct (Y/M)", "defaults": { "area": "Hele landet", "period": "l(Y:10)" } },
      { "id": "y25i03", "note": "Sæsonkorrigeret fuldtidsledige (M)", "defaults": { "area": "Hele landet", "period": "l(M:12)" } }
    ],
    "dimensionHints": {
      "gender": ["køn", "kvinder", "mænd"],
      "pct": ["pct", "procent"]
    }
  }
]

Guidelines
----------
- Use plain Danish words in `labels`. Accents/spacing/hyphens are normalized, so “arbejdsløshed”, “arbejds loshed”, “arbejds-loshed” all match.
- Put the best table first in `tables`. Add a short `note` and sensible `defaults` for `area` and `period`.
- Add dimension hints when applicable. The planner uses these to infer `_kon` (gender) or pick rate vs. level.

Runtime
-------
- Loaded at server start. Change `config/concepts.json` and restart to apply.
- Endpoints: `/api/concepts`, `/api/concepts/match?q=...` for quick checks.

Roadmap
-------
- Auto-suggest concepts by mining `/v2/tables/json` (table names, measurement names) and proposing labels.
- Optional semantic reranker via HuggingFace embeddings (set `HUGGINGFACE_API_TOKEN`).

